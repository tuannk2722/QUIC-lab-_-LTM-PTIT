# P10 handshake CSV-derived results

Experiment: `bulk_20261001T120746_3610801801ce229c`; execution: `loopback-test`.

All scheduled rows: 3; success 0; failed 3; measured 3; excluded warmups 0.

Transfer success remains a bytes/FIN/checksum result. Latencies use only successful targets achieving the requested mode. Rejected fallback and unachieved modes remain in transfer counts and are excluded from mode latency distributions. Ticket warm-ups are logged separately outside target denominators. p95 is nearest-rank; no outliers removed.

Early qualification uses actual TLS resumption/Used0RTT and REQUEST enqueue before the client observed handshake completion. P11 packet corroboration remains pending; API qualification does not establish full accepted-early evidence.

| Scenario | Mode | Metric | Attempted | Transfer success | Failed | Mode achieved | Fallback | Unachieved success | Median | p95 |
|---|---|---|---:|---:|---:|---:|---:|---:|---:|---:|
| loopback-test | cold | total_ms | 1 | 0 | 1 | 0 | 0 | 0 | — | — |
| loopback-test | cold | ttfa_ms | 1 | 0 | 1 | 0 | 0 | 0 | — | — |
| loopback-test | cold | handshake_ms | 1 | 0 | 1 | 0 | 0 | 0 | — | — |
| loopback-test | early | total_ms | 1 | 0 | 1 | 0 | 0 | 0 | — | — |
| loopback-test | early | ttfa_ms | 1 | 0 | 1 | 0 | 0 | 0 | — | — |
| loopback-test | early | handshake_ms | 1 | 0 | 1 | 0 | 0 | 0 | — | — |
| loopback-test | resumed | total_ms | 1 | 0 | 1 | 0 | 0 | 0 | — | — |
| loopback-test | resumed | ttfa_ms | 1 | 0 | 1 | 0 | 0 | 0 | — | — |
| loopback-test | resumed | handshake_ms | 1 | 0 | 1 | 0 | 0 | 0 | — | — |

Artifacts: runs.csv, streams.csv, raw/, schedule.json, manifest.json, merge.json, summary.csv, resource-summary.csv and plots/.

Limitations: shared WSL2 host/kernel/CPU, different kernel/userspace transport and scheduling, differing packetization/congestion control; paired seed does not imply identical lost application bytes. Configured loss affects downstream control/ACK traffic too; qdisc drops can include overflow. Small cohorts/p95 describe this testbed and workload. Performance plots do not establish HOL causation. P11 qlog/PCAP/progress and packet corroboration remain pending.
