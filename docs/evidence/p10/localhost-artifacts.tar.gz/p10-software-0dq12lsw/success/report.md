# P10 handshake CSV-derived results

Experiment: `bulk_20261001T120645_cc8b8f53095c5a27`; execution: `loopback-test`.

All scheduled rows: 96; success 96; failed 0; measured 90; excluded warmups 6.

Transfer success remains a bytes/FIN/checksum result. Latencies use only successful targets achieving the requested mode. Rejected fallback and unachieved modes remain in transfer counts and are excluded from mode latency distributions. Ticket warm-ups are logged separately outside target denominators. p95 is nearest-rank; no outliers removed.

Early qualification uses actual TLS resumption/Used0RTT and REQUEST enqueue before the client observed handshake completion. P11 packet corroboration remains pending; API qualification does not establish full accepted-early evidence.

| Scenario | Mode | Metric | Attempted | Transfer success | Failed | Mode achieved | Fallback | Unachieved success | Median | p95 |
|---|---|---|---:|---:|---:|---:|---:|---:|---:|---:|
| loopback-test | cold | total_ms | 30 | 30 | 0 | 30 | 0 | 0 | 19.295 | 65.152 |
| loopback-test | cold | ttfa_ms | 30 | 30 | 0 | 30 | 0 | 0 | 19.290 | 65.138 |
| loopback-test | cold | handshake_ms | 30 | 30 | 0 | 30 | 0 | 0 | 13.373 | 53.623 |
| loopback-test | early | total_ms | 30 | 30 | 0 | 29 | 0 | 1 | 7.767 | 32.283 |
| loopback-test | early | ttfa_ms | 30 | 30 | 0 | 29 | 0 | 1 | 7.761 | 32.277 |
| loopback-test | early | handshake_ms | 30 | 30 | 0 | 29 | 0 | 1 | 7.117 | 32.168 |
| loopback-test | resumed | total_ms | 30 | 30 | 0 | 30 | 0 | 0 | 12.418 | 53.312 |
| loopback-test | resumed | ttfa_ms | 30 | 30 | 0 | 30 | 0 | 0 | 12.413 | 53.296 |
| loopback-test | resumed | handshake_ms | 30 | 30 | 0 | 30 | 0 | 0 | 8.709 | 38.972 |

Artifacts: runs.csv, streams.csv, raw/, schedule.json, manifest.json, merge.json, summary.csv, resource-summary.csv and plots/.

Limitations: shared WSL2 host/kernel/CPU, different kernel/userspace transport and scheduling, differing packetization/congestion control; paired seed does not imply identical lost application bytes. Configured loss affects downstream control/ACK traffic too; qdisc drops can include overflow. Small cohorts/p95 describe this testbed and workload. Performance plots do not establish HOL causation. P11 qlog/PCAP/progress and packet corroboration remain pending.
