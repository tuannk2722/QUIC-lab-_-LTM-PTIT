# P10 handshake CSV-derived results

Experiment: `bulk_20261002T024416_374361bd2627ff92`; execution: `ingress-ifb`.

All scheduled rows: 96; success 96; failed 0; measured 90; excluded warmups 6.

Transfer success remains a bytes/FIN/checksum result. Latencies use only successful targets achieving the requested mode. Rejected fallback and unachieved modes remain in transfer counts and are excluded from mode latency distributions. Ticket warm-ups are logged separately outside target denominators. p95 is nearest-rank; no outliers removed.

Early qualification uses actual TLS resumption/Used0RTT and REQUEST enqueue before the client observed handshake completion. P11 packet corroboration remains pending; API qualification does not establish full accepted-early evidence.

| Scenario | Mode | Metric | Attempted | Transfer success | Failed | Mode achieved | Fallback | Unachieved success | Median | p95 |
|---|---|---|---:|---:|---:|---:|---:|---:|---:|---:|
| rtt50-loss0 | cold | total_ms | 30 | 30 | 0 | 30 | 0 | 0 | 108.099 | 118.212 |
| rtt50-loss0 | cold | ttfa_ms | 30 | 30 | 0 | 30 | 0 | 0 | 108.090 | 118.208 |
| rtt50-loss0 | cold | handshake_ms | 30 | 30 | 0 | 30 | 0 | 0 | 55.792 | 61.359 |
| rtt50-loss0 | early | total_ms | 30 | 30 | 0 | 30 | 0 | 0 | 55.168 | 61.002 |
| rtt50-loss0 | early | ttfa_ms | 30 | 30 | 0 | 30 | 0 | 0 | 55.164 | 60.996 |
| rtt50-loss0 | early | handshake_ms | 30 | 30 | 0 | 30 | 0 | 0 | 55.051 | 60.952 |
| rtt50-loss0 | resumed | total_ms | 30 | 30 | 0 | 30 | 0 | 0 | 108.765 | 121.445 |
| rtt50-loss0 | resumed | ttfa_ms | 30 | 30 | 0 | 30 | 0 | 0 | 108.743 | 121.441 |
| rtt50-loss0 | resumed | handshake_ms | 30 | 30 | 0 | 30 | 0 | 0 | 55.228 | 68.162 |

Artifacts: runs.csv, streams.csv, raw/, schedule.json, manifest.json, merge.json, summary.csv, resource-summary.csv and plots/.

Limitations: shared WSL2 host/kernel/CPU, different kernel/userspace transport and scheduling, differing packetization/congestion control; paired seed does not imply identical lost application bytes. Configured loss affects downstream control/ACK traffic too; qdisc drops can include overflow. Small cohorts/p95 describe this testbed and workload. Performance plots do not establish HOL causation. P11 qlog/PCAP/progress and packet corroboration remain pending.
