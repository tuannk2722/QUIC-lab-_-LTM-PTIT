# P9 CSV-derived results

Experiment: `bulk_20261001T064654_138b43853c623b9e`; execution: `ingress-ifb`.

All scheduled rows: 256; success 256; failed 0; measured 240; excluded warmups 16.

Latency/goodput summarize successful measured trials. Failures remain in every denominator. p95 is nearest-rank; sample stddev is null below two observations. No outliers removed.

| Scenario | Transport | Metric | Attempted | Success | Failed | Median | p95 |
|---|---|---|---:|---:|---:|---:|---:|
| baseline | quic | total_ms | 30 | 30 | 0 | 2654.793 | 2728.348 |
| baseline | quic | ttfa_ms | 30 | 30 | 0 | 8.547 | 26.727 |
| baseline | quic | goodput_mbps | 30 | 30 | 0 | 19.004 | 19.009 |
| baseline | tcp | total_ms | 30 | 30 | 0 | 2649.439 | 2660.067 |
| baseline | tcp | ttfa_ms | 30 | 30 | 0 | 14.125 | 24.994 |
| baseline | tcp | goodput_mbps | 30 | 30 | 0 | 19.037 | 19.039 |
| rtt50-loss0 | quic | total_ms | 30 | 30 | 0 | 2811.900 | 2824.929 |
| rtt50-loss0 | quic | ttfa_ms | 30 | 30 | 0 | 109.297 | 119.531 |
| rtt50-loss0 | quic | goodput_mbps | 30 | 30 | 0 | 18.269 | 18.281 |
| rtt50-loss0 | tcp | total_ms | 30 | 30 | 0 | 2970.568 | 2979.177 |
| rtt50-loss0 | tcp | ttfa_ms | 30 | 30 | 0 | 265.171 | 274.205 |
| rtt50-loss0 | tcp | goodput_mbps | 30 | 30 | 0 | 17.570 | 17.580 |
| rtt50-loss1 | quic | total_ms | 30 | 30 | 0 | 12354.308 | 15358.483 |
| rtt50-loss1 | quic | ttfa_ms | 30 | 30 | 0 | 111.109 | 136.968 |
| rtt50-loss1 | quic | goodput_mbps | 30 | 30 | 0 | 4.094 | 5.313 |
| rtt50-loss1 | tcp | total_ms | 30 | 30 | 0 | 18312.296 | 22729.866 |
| rtt50-loss1 | tcp | ttfa_ms | 30 | 30 | 0 | 268.502 | 1271.995 |
| rtt50-loss1 | tcp | goodput_mbps | 30 | 30 | 0 | 2.765 | 3.601 |
| rtt50-loss3 | quic | total_ms | 30 | 30 | 0 | 24762.367 | 26574.108 |
| rtt50-loss3 | quic | ttfa_ms | 30 | 30 | 0 | 111.983 | 181.390 |
| rtt50-loss3 | quic | goodput_mbps | 30 | 30 | 0 | 2.037 | 2.245 |
| rtt50-loss3 | tcp | total_ms | 30 | 30 | 0 | 40898.681 | 45210.192 |
| rtt50-loss3 | tcp | ttfa_ms | 30 | 30 | 0 | 306.345 | 400.821 |
| rtt50-loss3 | tcp | goodput_mbps | 30 | 30 | 0 | 1.234 | 1.373 |

Artifacts: runs.csv, streams.csv, raw/, schedule.json, manifest.json, merge.json, summary.csv, resource-summary.csv and plots/.

Limitations: shared WSL2 host/kernel/CPU, different kernel/userspace transport and scheduling, differing packetization/congestion control; paired seed does not imply identical lost application bytes. Configured loss affects downstream control/ACK traffic too; qdisc drops can include overflow. Small cohorts/p95 describe this testbed and workload. Performance plots do not establish HOL causation. Resumption/early and qlog/PCAP/progress are separate cohorts; see docs/REPORT.md.
