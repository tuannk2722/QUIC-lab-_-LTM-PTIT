# Annotated G11 evidence

Instrumentation is enabled; these runs are excluded from main performance. All attempts are retained.

Progress is cumulative validated payload at 16 KiB thresholds; points inside one frame share its completion time. Qlog references and client t0 are distinct clocks.

Receiver eth0 AF_PACKET may observe bytes before IFB loss: use TCP cumulative ACK/SACK or client qlog receive to establish actual reception.

Selected HOL pair: None; HOL status: NOT_RUN. Full demo complete: False.

Early REQUEST proof: BLOCKED. Qlog STREAM range alone does not expose payload content.

- handshake_quic_cold: success=True, payload points=1; [local viewer](viewers/handshake_quic_cold.html), [timeline](viewers/handshake_quic_cold.png).
- handshake_quic_resumed: success=True, payload points=1; [local viewer](viewers/handshake_quic_resumed.html), [timeline](viewers/handshake_quic_resumed.png).
- handshake_quic_early: success=True, payload points=1; [local viewer](viewers/handshake_quic_early.html), [timeline](viewers/handshake_quic_early.png).
  early_qlog: {"api_qualified": true, "limitation": "qlog identifies STREAM range, not encrypted payload content; decrypted PCAP REQUEST required for full proof", "matched": [{"length": 32, "offset": 0, "packet_number": 0, "qlog_time_ms": 0.805035, "resource_id": 1, "stream_id": 0}], "received": [{"length": 32, "offset": 0, "packet_number": 0, "qlog_time_ms": 9.198074, "resource_id": 1, "stream_id": 0}], "sent": [{"length": 32, "offset": 0, "packet_number": 0, "qlog_time_ms": 0.805035, "resource_id": 1, "stream_id": 0}], "status": "PASS"}
- bulk_quic_cold: success=True, payload points=384; [local viewer](viewers/bulk_quic_cold.html), [timeline](viewers/bulk_quic_cold.png).
  hol: {"reason": "software correctness has no impaired paired captures", "status": "NOT_RUN"}
- bulk_tcp_cold: success=True, payload points=384; [local viewer](viewers/bulk_tcp_cold.html), [timeline](viewers/bulk_tcp_cold.png).
  hol: {"reason": "software correctness has no impaired paired captures", "status": "NOT_RUN"}
- bulk_tcp_tls_failure: success=False, payload points=0; [local viewer](viewers/bulk_tcp_tls_failure.html), [timeline](viewers/bulk_tcp_tls_failure.png).
  hol: {"reason": "software correctness has no impaired paired captures", "status": "NOT_RUN"}
