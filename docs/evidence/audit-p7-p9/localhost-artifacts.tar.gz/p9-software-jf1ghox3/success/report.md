# P9 CSV-derived results

Experiment: `bulk_20261001T084130_a13a403fbd3ffde7`; execution: `loopback-test`.

All scheduled rows: 6; success 6; failed 0; measured 4; excluded warmups 2.

Latency/goodput summarize successful measured trials. Failures remain in every denominator. p95 is nearest-rank; sample stddev is null below two observations. No outliers removed.

| Scenario | Transport | Metric | Attempted | Success | Failed | Median | p95 |
|---|---|---|---:|---:|---:|---:|---:|
| loopback-test | quic | total_ms | 2 | 2 | 0 | 61.588 | 85.773 |
| loopback-test | quic | ttfa_ms | 2 | 2 | 0 | 3.206 | 3.252 |
| loopback-test | quic | goodput_mbps | 2 | 2 | 0 | 1025.828 | 1449.052 |
| loopback-test | tcp | total_ms | 2 | 2 | 0 | 16.137 | 21.896 |
| loopback-test | tcp | ttfa_ms | 2 | 2 | 0 | 3.513 | 5.377 |
| loopback-test | tcp | goodput_mbps | 2 | 2 | 0 | 4049.773 | 5640.406 |

Artifacts: runs.csv, streams.csv, raw/, schedule.json, manifest.json, merge.json, summary.csv, resource-summary.csv and plots/.

Limitations: shared WSL2 host/kernel/CPU, different kernel/userspace transport and scheduling, differing packetization/congestion control; paired seed does not imply identical lost application bytes. Configured loss affects downstream control/ACK traffic too; qdisc drops can include overflow. Small cohorts/p95 describe this testbed and workload. Performance plots do not establish HOL causation. P10 resumption/early and P11 qlog/PCAP/progress evidence remain pending.
